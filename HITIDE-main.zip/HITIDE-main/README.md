# HITIDE
Models for the Hi-TIDE paper
